// L is brought in as a global from the previous <script> tag in index.html.
// same goes for data


const center = L.latLng(0, 0);
const zoom = 1;
const minZoom = -5;
const crs = L.CRS.Simple;

const locMap = L.map("locMap", {
  center,
  zoom,
  minZoom,
  crs,
});

const bounds = [
  [0, 0],
  [data.height, data.width],
];

L.imageOverlay("inner-mongolia.png", bounds).addTo(locMap);

locMap.fitBounds(bounds);


const osmMap = L.map("osmMap", {
    center: [40.692169, 117.16382],
    zoom: 5,
})

L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
	attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
}).addTo(osmMap);

function handleClick(event) {
    const lat = event.srcElement.dataset.lat;
    const lng = event.srcElement.dataset.lng;
    
    osmMap.flyTo([lat, lng], 11);
}

for (const place of data.places) {
  
    const popupTemplate = `
<h1>${place.name}</h1>
<p>${place.description}</p>
<button 
data-lat="${place.cartesianCoords[0]}"
data-lng="${place.cartesianCoords[1]}"
onClick='handleClick(event);'>Click on me</button>
`;
    L.circleMarker([place.y, place.x])
    .bindPopup(popupTemplate)
    .addTo(locMap);

    L.marker(place.cartesianCoords)
    .addTo(osmMap);
    
}
