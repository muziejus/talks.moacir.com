const participants = [
    {
      name: "McGill University",
      latitude: 45.5047847,
      longitude: -73.5771511
    },
    {
      name: "Duke University",
      latitude: 36.0014258,
      longitude: -78.9382286
    },
    {
      name: "University of Florida",
      latitude: 29.6436325,
      longitude: -82.3549302
    },
    {
      name: "Tufts University",
      latitude: 42.4085371,
      longitude: -71.1182729
    },
    {
      name: "IIT Indore, India",
      latitude: 22.6758996,
      longitude: 75.8783118
    },
    {
      name: "University College London",
      latitude: 51.5245592,
      longitude: -0.1340401
    },
    {
      name: "Columbia University",
      latitude: 40.8075355,
      longitude: -73.9625727
    },
    {
      name: "USC",
      latitude: 34.0223519,
      longitude: -118.285117
    },
    {
      name: "UCSB",
      latitude: 34.4139629,
      longitude: -119.848947
    },
    {
      name: "MOVES European Joint Doctorate (University of Kent and Freie Universität Berlin)",
      latitude: 52.4543245,
      longitude: 13.2934768
    },
    {
      name: "Brown University",
      latitude: 41.8267718,
      longitude: -71.4025482
    },
    {
      name: "New School for Social Research",
      latitude: 40.7369978,
      longitude: -73.9922508
    },
    {
      name: "Jadavpur University",
      latitude: 22.4966896,
      longitude: 88.3713127
    },
    {
      name: "SUNY Binghamton University",
      latitude: 42.0894288,
      longitude: -75.9694885
    },
    {
      name: "Temple University",
      latitude: 39.9805942,
      longitude: -75.1557376
    },
    {
      name: "Tulane University",
      latitude: 29.9407282,
      longitude: -90.1203167
    },
    {
      name: "UC Berkeley",
      latitude: 37.8718992,
      longitude: -122.2585399
    },
    {
      name: "Iowa State University",
      latitude: 42.0266573,
      longitude: -93.6464516
    },
    {
      name: "University of Arkansas",
      latitude: 36.0686895,
      longitude: -94.1748471
    },
    {
      name: "UC Berkeley",
      latitude: 37.8718992,
      longitude: -122.2585399
    },
    {
      name: "UC San Diego",
      latitude: 32.8800604,
      longitude: -117.2340135
    },
    {
      name: "Indiana University",
      latitude: 39.1784384,
      longitude: -86.5133166
    },
    {
      name: "University of East Anglia",
      latitude: 52.6219215,
      longitude: 1.2391761
    },
    {
      name: "Brandeis University",
      latitude: 42.3657375,
      longitude: -71.2585661
    },
    {
      name: "University of Illinois",
      latitude: 40.1019523,
      longitude: -88.2271615
    },
    {
      name: "University of Lagos",
      latitude: 6.515759,
      longitude: 3.3898447
    },
    {
      name: "University of Maryland, Baltimore County",
      latitude: 39.2542822,
      longitude: -76.7100102
    },
    {
      name: "MIT",
      latitude: 42.360091,
      longitude: -71.09416
    },
    {
      name: "Institute of Southeast Asian Studies (ISEAS)-Yusof Ishak Institute",
      latitude: 1.2914943,
      longitude: 103.776784
    }
   ];