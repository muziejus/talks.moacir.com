const locMap = L.map("locMap", {
    center: [0,0],
    zoom: 4,
});

L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
	attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
}).addTo(locMap);

for (const institution of participants){
    L.marker([institution.latitude, institution.longitude])
    .bindPopup(institution.name).addTo(locMap)
}