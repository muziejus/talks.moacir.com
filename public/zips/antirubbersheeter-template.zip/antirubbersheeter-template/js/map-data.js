const data = {
  "width": 1137,
  "placesstring": "张家口, 古北口",
  "imgururl": "https://i.imgur.com/t8tGO19.jpg",
  "height": 614,
  "places": [
    {
      "name": "张家口",
      "description": "I am where the Winter Olympics Happened",
      "y": 125,
      "x": 559,
      "cartesianCoords": [40.769, 114.886],
    },
    {
      "name": "古北口",
      "description": "I am some other gate.",
      "y": 37.25,
      "x": 703.75,
      "cartesianCoords": [40.692169, 117.16382],
    }
  ]
}