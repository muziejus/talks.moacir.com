# antirubbersheeter-template
A very basic, step 1 template for use with the antirubbersheeter.
